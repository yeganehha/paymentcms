<?php
return [
	'info' => [
		'name' => 'Admin',
		'description' => 'Admin area for payment cms',
		'version' => '1.0.0.0',
		'author' => 'erfan ebrahimi',
		'support' => 'http://erfanebrahimi.ir',
	]
];