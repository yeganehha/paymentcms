<?php
/**
 * Created by Yeganehha .
 * User: Erfan Ebrahimi (http://ErfanEbrahimi.ir)
 * Date: 5/28/2019
 * Time: 2:30 AM
 * project : paymentCMS
 * virsion : 0.0.0.1
 * update Time : 5/28/2019 - 2:30 AM
 * Discription of this Page :
 */


if (!defined('paymentCMS')) die('<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css"><div class="container" style="margin-top: 20px;"><div id="msg_1" class="alert alert-danger"><strong>Error!</strong> Please do not set the url manually !! </div></div>');


return [
	'logPageApp' => 'گزارش فعالیت (log)',
	'logPageAppDescription' => 'توسط این پلاگین شما می توانید کلیه صفحاتی که کاربران شما بازدید کردند را در گزارش بازدید کاربران مشاهده فرمایید.',
	'view_webSite_page' => 'بازدید از صفحه',
	'logs' => 'گزارش عملکرد',
	'currentUrl' => 'آدرس صفحه',
	'urlFrom' => 'آدرس صفحه ارجاع دهنده',
	'showViewPage' => 'نمایش صفحاتی که بازدید شده',
];