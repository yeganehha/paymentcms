<?php
return [
	'info' => [
		'name' => 'invoice',
		'description' => 'invoice area for payment cms',
		'version' => '1.0.0.0',
		'author' => 'erfan ebrahimi',
		'support' => 'http://erfanebrahimi.ir',
	]
];