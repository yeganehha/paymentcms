<?php
/**
 * Created by Yeganehha .
 * User: Erfan Ebrahimi (http://ErfanEbrahimi.ir)
 * Date: 3/23/2019
 * Time: 3:38 PM
 * project : paymentCMS
 * virsion : 0.0.0.1
 * update Time : 3/23/2019 - 3:38 PM
 * Discription of this Page :
 */


if (!defined('paymentCMS')) die('<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css"><div class="container" style="margin-top: 20px;"><div id="msg_1" class="alert alert-danger"><strong>Error!</strong> Please do not set the url manually !! </div></div>');


return [
	'canNotInsertFieldValue' => 'در وارد سازی اطلاعات درخواستی صورتحساب مشکلی پیش آمده!',
	'canNotInsertItems' => 'در درج آیتم های صورتحساب مشکلی پیش آمده!',
	'canNotInsertInvoice' => 'در ثبت صورتحساب مشکلی پیش آمده!',
	'service_add_helper_name' => 'نام سرویس فقط در ناحیه مدیریت و برای شناسیی سریع تر سرویس به استفاده می شود.',
];